package com.example.myapplication.Tool;

import java.text.DecimalFormat;
//格式化数字
public class Format {
    public static DecimalFormat  decimalFormat1 = new DecimalFormat("#.##");

    public static DecimalFormat decimalFormat2 = new DecimalFormat("#.##E0");

}
